package com.reindra.moviecatalogue.util

enum class CategoryEnum(val value: String) {
    MOVIE("movie"),
    TV("tv")
}